package eportfolio;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Portfolio {
	private ArrayList<Investment> investments;
	private HashMap<String, ArrayList<Integer>> map;
	private double netGains;
	private String dataFile;

	public Portfolio(String file) {

		this.dataFile = file;
		this.investments = new ArrayList<Investment>();
		this.map = new HashMap<String, ArrayList<Integer>>();
		this.netGains = 0;
		try {
			BufferedReader br = new BufferedReader(new FileReader(dataFile));
			String line;
			while ((line = br.readLine()) != null) {
				String[] invLine = line.split(",");
				String type = invLine[0].split(" ")[0];
				String symbol = invLine[0].split(" ")[1];
				String name = invLine[1].split(":")[1].substring(1);
				double price = Double.parseDouble(invLine[2].split(":")[1].substring(2));
				int qty = Integer.parseInt(invLine[3].split(":")[1].substring(1));
				double bv = Double.parseDouble(invLine[4].split(":")[1].substring(2));
				addNewInvestment(type, symbol, name, price, qty);
				investments.get(investments.size() - 1).setBookValue(bv);

			}
			br.close();
		} catch (Exception e) {
			System.out.println("File not found. Creating for write");
			e.printStackTrace();
		}
	}

	public ArrayList<Investment> getInvestments() {
		return investments;
	}

	public void setInvestments(ArrayList<Investment> investments) {
		this.investments = investments;
	}

	public double getNetGains() {
		return netGains;
	}

	public void setNetGains(double netGains) {
		this.netGains = netGains;
	}

	public boolean investmentBought(String inSymbol) {
		for (Investment inv : investments) {
			if (inv.getSymbol().equalsIgnoreCase(inSymbol))
				return true;
		}
		return false;
	}

	public void updateBoughtInvestment(String inSymbol, double inPrice, int inQty) {
		for (Investment inv : investments) {
			if (inv.getSymbol().equalsIgnoreCase(inSymbol)) {
				inv.setPrice(inPrice);
				inv.setQuantity(inv.getQuantity() + inQty);
				inv.setBookValue(inv.getBookValue() + inPrice * inQty + inv.getCommission());
			}
		}
	}

	public void addNewInvestment(String type, String inSymbol, String inName, double inPrice, int inQty) {

		if (type.equalsIgnoreCase("stock")) {
			investments.add(new Stock(inSymbol, inName, inPrice, inQty));
		} else {
			investments.add(new MutualFund(inSymbol, inName, inPrice, inQty));
		}
		String[] words = inName.toLowerCase().split(" ");
		for (String word : words) {
			if (this.map.containsKey(word)) {
				map.get(word).add(investments.size() - 1);
			} else {
				ArrayList<Integer> indexes = new ArrayList<Integer>();
				indexes.add(investments.size() - 1);
				map.put(word, indexes);

			}
		}
	}

	private ArrayList<Investment> searchInvestmentBySymbol(String inSymbol, ArrayList<Investment> investments) {
		if (inSymbol.trim().isEmpty())
			return investments;
		ArrayList<Investment> res = new ArrayList<Investment>();
		for (Investment inv : investments) {
			if (inv.getSymbol().equalsIgnoreCase(inSymbol)) {
				res.add(inv);
				break;
			}
		}
		return res;
	}

	private ArrayList<Investment> searchInvestmentByKeywords(String keywords) {
		if (keywords.trim().isEmpty()) {
			return this.investments;
		}
		ArrayList<Investment> res = new ArrayList<Investment>();
		ArrayList<String> splitKeywords = new ArrayList<String>();
		splitKeywords.addAll(Arrays.asList(keywords.split(" ")));
		ArrayList<ArrayList<Integer>> allMatches = new ArrayList<ArrayList<Integer>>();
		int comp = Integer.MAX_VALUE;
		int smallestIndex = 0;
		for (String keyword : splitKeywords) {
			ArrayList<Integer> wordMatchInv = map.get(keyword);
			if (wordMatchInv == null)
				return res;

			allMatches.add(wordMatchInv);
			if (wordMatchInv.size() < comp) {
				comp = wordMatchInv.size();
				smallestIndex = allMatches.size() - 1;
			}

		}

		if (allMatches.isEmpty())

		{
			return res;
		}
		ArrayList<Integer> smallest = new ArrayList<Integer>(allMatches.get(smallestIndex));
		allMatches.remove(smallestIndex);

		boolean match = true;
		for (ArrayList<Integer> oneMatchLine : allMatches) {
			if (!oneMatchLine.containsAll(smallest)) {
				match = false;
				break;
			}
		}
		if (match) {
			for (Integer i : smallest) {
				res.add(investments.get(i));
			}
		}

		return res;
	}

	private ArrayList<Investment> searchInvestmentByPriceRange(String range, ArrayList<Investment> investments) {
		if (range.trim().isEmpty()) {
			return investments;
		}

		ArrayList<Investment> res = new ArrayList<Investment>();
		double low = 0;
		double high = Double.MAX_VALUE - 8;

		if (range.contains("-")) {
			if (range.charAt(0) == '-') {
				high = Double.parseDouble(range.replace("-", ""));
			} else if (range.charAt(range.length() - 1) == '-') {
				low = Double.parseDouble(range.replace("-", ""));
			} else {
				low = Double.parseDouble(range.substring(0, range.indexOf('-')));
				high = Double.parseDouble(range.substring(range.indexOf('-') + 1));
			}
		} else {
			low = Double.parseDouble(range);
			high = low;
		}
		for (Investment inv : investments) {
			if (low <= inv.getPrice() && inv.getPrice() <= high) {
				res.add(inv);
			}
		}
		return res;
	}

	public void searchAllInvestments(String inSymbol, String keywords, String priceRange) {
		ArrayList<Investment> res = searchInvestmentByKeywords(keywords);
		res = searchInvestmentBySymbol(inSymbol, res);
		res = searchInvestmentByPriceRange(priceRange, res);

		for (Investment inv : res) {
			System.out.println(inv.toString());
		}
	}

	private void removeFromMap(Investment i) {
		Integer index = this.investments.indexOf(i);
		for (String key : map.keySet()) {
			if (map.get(key).contains(index)) {
				map.get(key).remove(index);
			}
		}
	}

	public void sellInvestment(String inSymbol, double inPrice, int inQty) {

		for (Investment inv : this.investments) {
			if (inv.getSymbol().equalsIgnoreCase(inSymbol)) {
				if (inv.getQuantity() == inQty) {// full
					netGains = inPrice * inQty - inv.getCommission() - inv.getBookValue();
					removeFromMap(inv);
					this.investments.remove(inv);

				} else if (inv.getQuantity() > inQty) {// partial
					double pay = inPrice * inQty - inv.getCommission();
					double sellBV = inv.getBookValue() * (inv.getQuantity() - inQty) / inv.getQuantity();
					this.netGains = pay - sellBV;
					inv.setBookValue(inv.getBookValue() - sellBV);
					inv.setQuantity(inv.getQuantity() - inQty);
				} else {
					System.out.printf("Not enough %s to sell", inSymbol);
				}
				return;
			}
		}

		System.out.printf("%s not found in owned stocks", inSymbol);

	}

	public void updateDataFile() {
		try {
			FileWriter fw = new FileWriter(this.dataFile);
			for (Investment inv : this.investments) {
				fw.write(inv.toString() + "\n");
			}
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
