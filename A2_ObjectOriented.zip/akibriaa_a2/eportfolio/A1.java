package eportfolio;

import java.util.Scanner;

public class A1 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);
		String line = "";
		String inType, inSymbol, inName, inKeywords, inRange;
		double inPrice;
		int inQty;
		Portfolio myPortfolio = new Portfolio(args[0]);

		while (!line.equalsIgnoreCase("quit") && !line.equals("q")) {
			System.out.println("Enter:\n\tBuy\n\tSell\n\tUpdate\n\tGetGain\n\tSearch\n\tQuit");
			System.out.println();
			line = reader.nextLine().toLowerCase();

			switch (line) {
			case "buy":
				System.out.println("Enter <Investment Type> <Ticker Symbol>");
				line = reader.nextLine().toUpperCase();
				String buyCmd[] = line.split(" ");
				inType = buyCmd[0];
				inSymbol = buyCmd[buyCmd.length - 1];
				if (buyCmd.length < 2 || inSymbol.trim().isEmpty()) {
					System.out.println("Bad buy inputs");
					break;
				}
				switch (inType) {
				case "STOCK":
				case "MUTUALFUND":
					System.out.println("Enter price for " + inSymbol);
					inPrice = Double.parseDouble(reader.nextLine());
					System.out.println("Enter quantity of " + inSymbol + " to buy");
					inQty = Integer.parseInt(reader.nextLine());
					if (myPortfolio.investmentBought(inSymbol)) {
						myPortfolio.updateBoughtInvestment(inSymbol, inPrice, inQty);
					} else {
						System.out.println("Enter name of " + inSymbol);
						inName = reader.nextLine();
						myPortfolio.addNewInvestment(inType, inSymbol, inName, inPrice, inQty);
					}

					break;

				default:
					System.out.println("Bad input, Enter stock or mutualfund for investment");
					break;
				}

				break;
			case "sell":
				System.out.println("Enter <investment> <symbol>");
				String sellCmd[] = reader.nextLine().toUpperCase().split(" ");
				inSymbol = sellCmd[sellCmd.length - 1];
				inType = sellCmd[0];
				if (sellCmd.length < 2 || inSymbol.trim().isEmpty()) {
					System.out.println("Bad sell input");
					break;
				}
				System.out.println("Enter price to sell " + inSymbol);
				inPrice = Double.parseDouble(reader.nextLine());
				System.out.printf("Enter quantity of %s to sell\n", inSymbol);
				inQty = Integer.parseInt(reader.nextLine());

			
				myPortfolio.sellInvestment(inSymbol, inPrice, inQty);
				
				break;
			case "update":

				for (Investment inv : myPortfolio.getInvestments()) {
					System.out.println("Enter a new price for " + inv.getSymbol());
					inPrice = Double.parseDouble(reader.nextLine());
					inv.setPrice(inPrice);
				}
				break;
			case "getgain":
				System.out.printf("Net gains: %f\n", myPortfolio.getNetGains());
				break;
			case "search":

				System.out.println("Enter search symbol");
				inSymbol = reader.nextLine();

				System.out.println("Enter search keyword(s)");
				inKeywords = reader.nextLine();

				System.out.println("Enter search price range");
				inRange = reader.nextLine();

				myPortfolio.searchAllInvestments(inSymbol, inKeywords, inRange);
				break;
			case "quit":
			case "q":
				myPortfolio.updateDataFile();
				System.out.println("Good-bye!");
				break;
			default:
				System.out.println("Invalid Input");
				break;
			}
		}

		reader.close();
	}

}
