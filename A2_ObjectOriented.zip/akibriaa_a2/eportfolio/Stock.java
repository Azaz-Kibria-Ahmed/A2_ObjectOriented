package eportfolio;

public class Stock extends Investment
{
	public Stock(String symbol, String name, double price, int quantity) {
		super(symbol, name, price, quantity);
		super.setCommission(9.99);
		super.setBookValue(super.getBookValue()+super.getCommission());
	}
		
	public String toString() {
		return String.format("Stock %s",super.toString());
	}
	
	
}
